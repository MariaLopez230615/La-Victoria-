# La Victoria

Sitio estático autocontenido para GitHub Pages.

## Publicación
1. Reemplazar el archivo `index.html` del repositorio por este.
2. No hace falta subir carpetas de imágenes, CSS ni JavaScript: todo está incluido dentro del mismo archivo.
3. GitHub Pages seguirá usando el mismo enlace del repositorio.

La demo utiliza fichas virtuales almacenadas localmente en el navegador.
